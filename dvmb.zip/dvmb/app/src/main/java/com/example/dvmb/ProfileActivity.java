
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		android_large___4
	 *	@date 		Thursday 05th of October 2023 09:04:55 AM
	 *	@title 		Page 4
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package com.example.dvmb;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class ProfileActivity extends Activity {

	
	private View _bg__android_large___4_ek2;
	private View rectangle_1;
	private ImageView image_9;
	private ImageView image_2;
	private ImageView image_3;
	private ImageView image_16;
	private View rectangle_35;
	private TextView t_i_kho_n;
	private ImageView rectangle_47;
	private View rectangle_47_ek1;
	private View rectangle_48;
	private View rectangle_49;
	private View rectangle_50;
	private ImageView ellipse_1;
	private TextView c__nh_n;
	private TextView th_ng_tin_t_i_kho_n;
	private TextView ti_n__ch;
	private View rectangle_47_ek2;
	private View rectangle_51;
	private View rectangle_52;
	private ImageView rectangle_53;
	private ImageView rectangle_54;
	private TextView th_ng_tin_t_i_kho_n_ek1;
	private ImageView rectangle_61;
	private ImageView rectangle_62;
	private TextView th_ng_tin_t_i_kho_n_ek2;
	private ImageView rectangle_59;
	private ImageView rectangle_60;
	private TextView th_ng_tin_t_i_kho_n_ek3;
	private ImageView rectangle_57;
	private ImageView rectangle_58;
	private TextView th_ng_tin_t_i_kho_n_ek4;
	private ImageView rectangle_55;
	private ImageView rectangle_56;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_profile);

		
		_bg__android_large___4_ek2 = (View) findViewById(R.id._bg__android_large___4_ek2);
		rectangle_1 = (View) findViewById(R.id.rectangle_1);
		image_9 = (ImageView) findViewById(R.id.image_9);
		image_2 = (ImageView) findViewById(R.id.image_2);
		image_3 = (ImageView) findViewById(R.id.image_3);
		image_16 = (ImageView) findViewById(R.id.image_16);
		rectangle_35 = (View) findViewById(R.id.rectangle_35);
		rectangle_47 = (ImageView) findViewById(R.id.rectangle_47);
		rectangle_47_ek1 = (View) findViewById(R.id.rectangle_47_ek1);
		rectangle_48 = (View) findViewById(R.id.rectangle_48);
		rectangle_49 = (View) findViewById(R.id.rectangle_49);
		rectangle_50 = (View) findViewById(R.id.rectangle_50);
		ellipse_1 = (ImageView) findViewById(R.id.ellipse_1);
		rectangle_47_ek2 = (View) findViewById(R.id.rectangle_47_ek2);
		rectangle_51 = (View) findViewById(R.id.rectangle_51);
		rectangle_52 = (View) findViewById(R.id.rectangle_52);
		rectangle_53 = (ImageView) findViewById(R.id.rectangle_53);
		rectangle_54 = (ImageView) findViewById(R.id.rectangle_54);
		th_ng_tin_t_i_kho_n_ek1 = (TextView) findViewById(R.id.th_ng_tin_t_i_kho_n_ek1);
		rectangle_61 = (ImageView) findViewById(R.id.rectangle_61);
		rectangle_62 = (ImageView) findViewById(R.id.rectangle_62);
		th_ng_tin_t_i_kho_n_ek2 = (TextView) findViewById(R.id.th_ng_tin_t_i_kho_n_ek2);
		rectangle_59 = (ImageView) findViewById(R.id.rectangle_59);
		rectangle_60 = (ImageView) findViewById(R.id.rectangle_60);
		th_ng_tin_t_i_kho_n_ek3 = (TextView) findViewById(R.id.th_ng_tin_t_i_kho_n_ek3);
		rectangle_57 = (ImageView) findViewById(R.id.rectangle_57);
		rectangle_58 = (ImageView) findViewById(R.id.rectangle_58);
		th_ng_tin_t_i_kho_n_ek4 = (TextView) findViewById(R.id.th_ng_tin_t_i_kho_n_ek4);
		rectangle_55 = (ImageView) findViewById(R.id.rectangle_55);
		rectangle_56 = (ImageView) findViewById(R.id.rectangle_56);

		image_9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(ProfileActivity.this,HomeActivity.class );
				startActivity(i);
			}
		});
		image_2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(ProfileActivity.this,BookingActivity.class );
				startActivity(i);
			}
		});
		image_3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(ProfileActivity.this,AnnouceActivity.class );
				startActivity(i);
			}
		});
		//custom code goes here
		rectangle_47.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(ProfileActivity.this,HomeActivity.class );
				startActivity(i);
			}
		});
		//custom code goes here
	
	}
}
	
	