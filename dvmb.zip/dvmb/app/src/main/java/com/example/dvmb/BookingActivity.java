
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		activity_booking
	 *	@date 		Thursday 05th of October 2023 04:29:12 AM
	 *	@title 		Page 3
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package com.example.dvmb;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class BookingActivity extends Activity {

	
	private View _bg__activity_booking_ek2;
	private View rectangle_1;
	private ImageView image_1;
	private ImageView image_13;

	private ImageView image_6;
	private ImageView image_3;
	private ImageView image_16;
	private View rectangle_20;
	private View rectangle_21;
	private View rectangle_26;
	private View rectangle_27;
	private TextView kh__h_i;
	private TextView m_t_chi_u;
	private TextView t_m_ki_m_chuy_n_bay;
	private TextView m__khuy_n_m_i__n_u_c___;
	private TextView nhi_u_ch_ng;
	private View rectangle_22;
	private View rectangle_23;
	private View rectangle_24;
	private View rectangle_25;
	private TextView _i_m__i;
	private TextView tp_h__ch__minh__vn;
	private TextView sgn;
	private TextView _i_m___n;
	private TextView h_nh_kh_ch;
	private TextView ___l_t__vn;
	private TextView dli;
	private TextView ng__i_l_n;
	private TextView tr__em__2_12_tu_i_;
	private TextView tr__em__d__i_2_tu_i_;
	private View rectangle_28;
	private View rectangle_29;
	private View rectangle_30;
	private View rectangle_47;

	private View rectangle_35;
	private TextView t_m_ki_m_chuy_n_bay_ek1;
	private View rectangle_39;
	private View rectangle_40;
	private TextView __t_v__m_y_bay;
	private ImageView rectangle_46;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_booking);

		
		_bg__activity_booking_ek2 = (View) findViewById(R.id._bg__activity_booking_ek2);
		rectangle_1 = (View) findViewById(R.id.rectangle_1);
		image_1 = (ImageView) findViewById(R.id.image_1);
		image_6 = (ImageView) findViewById(R.id.image_6);
		image_3 = (ImageView) findViewById(R.id.image_3);
		image_16 = (ImageView) findViewById(R.id.image_16);

		rectangle_20 = (View) findViewById(R.id.rectangle_20);
		rectangle_21 = (View) findViewById(R.id.rectangle_21);
		rectangle_26 = (View) findViewById(R.id.rectangle_26);
		rectangle_27 = (View) findViewById(R.id.rectangle_27);
		m_t_chi_u = (TextView) findViewById(R.id.m_t_chi_u);
		t_m_ki_m_chuy_n_bay = (TextView) findViewById(R.id.t_m_ki_m_chuy_n_bay);
		m__khuy_n_m_i__n_u_c___ = (TextView) findViewById(R.id.m__khuy_n_m_i__n_u_c___);
		nhi_u_ch_ng = (TextView) findViewById(R.id.nhi_u_ch_ng);
		rectangle_22 = (View) findViewById(R.id.rectangle_22);
		rectangle_23 = (View) findViewById(R.id.rectangle_23);
		rectangle_24 = (View) findViewById(R.id.rectangle_24);
		rectangle_25 = (View) findViewById(R.id.rectangle_25);
		_i_m__i = (TextView) findViewById(R.id._i_m__i);
		tp_h__ch__minh__vn = (TextView) findViewById(R.id.tp_h__ch__minh__vn);
		sgn = (TextView) findViewById(R.id.sgn);
		_i_m___n = (TextView) findViewById(R.id._i_m___n);
		h_nh_kh_ch = (TextView) findViewById(R.id.h_nh_kh_ch);
		___l_t__vn = (TextView) findViewById(R.id.___l_t__vn);
		dli = (TextView) findViewById(R.id.dli);
		ng__i_l_n = (TextView) findViewById(R.id.ng__i_l_n);
		tr__em__2_12_tu_i_ = (TextView) findViewById(R.id.tr__em__2_12_tu_i_);
		tr__em__d__i_2_tu_i_ = (TextView) findViewById(R.id.tr__em__d__i_2_tu_i_);
		rectangle_28 = (View) findViewById(R.id.rectangle_28);
		rectangle_29 = (View) findViewById(R.id.rectangle_29);
		rectangle_30 = (View) findViewById(R.id.rectangle_30);
		rectangle_35 = (View) findViewById(R.id.rectangle_35);
		rectangle_39 = (View) findViewById(R.id.rectangle_39);
		rectangle_40 = (View) findViewById(R.id.rectangle_40);
		rectangle_46 = (ImageView) findViewById(R.id.rectangle_46);


		image_3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(BookingActivity.this,AnnouceActivity.class );
				startActivity(i);
			}
		});
		image_1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(BookingActivity.this,HomeActivity.class );
				startActivity(i);
			}
		});
		image_16.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(BookingActivity.this,ProfileActivity.class );
				startActivity(i);
			}
		});
		//custom code goes here
		rectangle_46.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(BookingActivity.this,HomeActivity.class );
				startActivity(i);
			}
		});


		//custom code goes here
	
	}
}
	
	