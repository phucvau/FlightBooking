
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		android_large___1
	 *	@date 		Monday 02nd of October 2023 07:09:20 AM
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package com.example.dvmb;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class HomeActivity extends Activity {

	
	private View _bg__android_large___1_ek2;
	private View rectangle_1;
	private ImageView image_8;
	private ImageView image_2;
	private ImageView image_3;
	private ImageView image_4;
	private ImageView image_7;
	private ImageView image_17;

	private ImageView rectangle_2;
	private ImageView rectangle_4;
	private ImageView rectangle_5;
	private ImageView rectangle_6;
	private ImageView rectangle_7;
	private ImageView rectangle_3;
	private ImageView rectangle_8;
	private ImageView rectangle_9;
	private TextView ph__qu_c;
	private TextView t__1_031_000_vnd;
	private TextView ___n_ng;
	private TextView t__943_000_vnd;
	private TextView singapore;
	private TextView t__3_843_000_vnd;
	private TextView seoul__h_n_qu_c;
	private TextView t__6_995_000_vnd;
	private View _bg__component_1;
	private TextView ___l_t;
	private TextView t__800_000_vnd;
	private TextView nha_trang;
	private TextView t__976_000_vnd;
	private TextView n_ng_t_m_tr_i_nghi_m;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);

		
		_bg__android_large___1_ek2 = (View) findViewById(R.id._bg__android_large___1_ek2);
		rectangle_1 = (View) findViewById(R.id.rectangle_1);
		image_2 = (ImageView) findViewById(R.id.image_2);
		image_3 = (ImageView) findViewById(R.id.image_3);
		image_4 = (ImageView) findViewById(R.id.image_4);
		image_7 = (ImageView) findViewById(R.id.image_7);
		image_17 = (ImageView) findViewById(R.id.image_17);
		image_8 = (ImageView) findViewById(R.id.image_8);


		rectangle_2 = (ImageView) findViewById(R.id.rectangle_2);
		rectangle_4 = (ImageView) findViewById(R.id.rectangle_4);
		rectangle_5 = (ImageView) findViewById(R.id.rectangle_5);
		rectangle_6 = (ImageView) findViewById(R.id.rectangle_6);
		rectangle_7 = (ImageView) findViewById(R.id.rectangle_7);
		rectangle_3 = (ImageView) findViewById(R.id.rectangle_3);
		rectangle_8 = (ImageView) findViewById(R.id.rectangle_8);
		rectangle_9 = (ImageView) findViewById(R.id.rectangle_9);


		image_7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(HomeActivity.this,AnnouceActivity.class );
				startActivity(i);
			}
		});
		//custom code goes here
		image_17.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(HomeActivity.this,BookingActivity.class );
				startActivity(i);
			}
		});

		image_8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(HomeActivity.this,ProfileActivity.class );
				startActivity(i);
			}
		});
	}
}
	
	