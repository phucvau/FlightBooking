
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		android_large___3
	 *	@date 		Thursday 05th of October 2023 03:34:21 AM
	 *	@title 		Page 2
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package com.example.dvmb;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class AnnouceActivity extends Activity {

	
	private View _bg__android_large___3_ek2;
	private View rectangle_1;
	private ImageView image_1;
	private ImageView image_2;
	private ImageView image_3;
	private ImageView image_4;
	private View rectangle_10;
	private ImageView image_5;
	private ImageView image_6;
	private ImageView image_7;
	private ImageView image_8;
	private View rectangle_20;
	private View rectangle_31;
	private ImageView image_9;
	private ImageView image_10;
	private ImageView image_11;
	private ImageView image_12;
	private View rectangle_33;
	private ImageView image_13;
	private ImageView image_15;
	private ImageView image_16;
	private View rectangle_35;
	private ImageView image_17;
	private TextView th_ng_b_o;
	private ImageView rectangle_47;
	private View rectangle_47_ek1;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_annouce);

		
		_bg__android_large___3_ek2 = (View) findViewById(R.id._bg__android_large___3_ek2);
		rectangle_1 = (View) findViewById(R.id.rectangle_1);
		image_1 = (ImageView) findViewById(R.id.image_1);
		image_2 = (ImageView) findViewById(R.id.image_2);
		image_3 = (ImageView) findViewById(R.id.image_3);
		image_4 = (ImageView) findViewById(R.id.image_4);
		rectangle_10 = (View) findViewById(R.id.rectangle_10);
		image_5 = (ImageView) findViewById(R.id.image_5);
		image_6 = (ImageView) findViewById(R.id.image_6);
		image_7 = (ImageView) findViewById(R.id.image_7);
		image_8 = (ImageView) findViewById(R.id.image_8);
		rectangle_20 = (View) findViewById(R.id.rectangle_20);
		rectangle_31 = (View) findViewById(R.id.rectangle_31);
		image_9 = (ImageView) findViewById(R.id.image_9);
		image_10 = (ImageView) findViewById(R.id.image_10);
		image_11 = (ImageView) findViewById(R.id.image_11);
		image_12 = (ImageView) findViewById(R.id.image_12);
		rectangle_33 = (View) findViewById(R.id.rectangle_33);
		image_13 = (ImageView) findViewById(R.id.image_13);
		image_15 = (ImageView) findViewById(R.id.image_15);
		image_16 = (ImageView) findViewById(R.id.image_16);
		rectangle_35 = (View) findViewById(R.id.rectangle_35);
		image_17 = (ImageView) findViewById(R.id.image_17);
		th_ng_b_o = (TextView) findViewById(R.id.th_ng_b_o);
		rectangle_47 = (ImageView) findViewById(R.id.rectangle_47);
		rectangle_47_ek1 = (View) findViewById(R.id.rectangle_47_ek1);


		image_13.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(AnnouceActivity.this,HomeActivity.class );
				startActivity(i);
			}
		});
		image_17.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(AnnouceActivity.this,BookingActivity.class );
				startActivity(i);
			}
		});
		image_16.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(AnnouceActivity.this,ProfileActivity.class );
				startActivity(i);
			}
		});
		//custom code goes here
		rectangle_47.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(AnnouceActivity.this,HomeActivity.class );
				startActivity(i);
			}
		});
		//custom code goes here

	}
}
	
	